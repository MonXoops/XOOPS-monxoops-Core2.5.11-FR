tinyMCE.addI18n('it.xoopscode_dlg',{
    xoopscode_title:"Inserisci codice",
    xoopscode_desc:"Inserisci codice",
    xoopscode_sub:"Digita/Incolla il codice:"
});
