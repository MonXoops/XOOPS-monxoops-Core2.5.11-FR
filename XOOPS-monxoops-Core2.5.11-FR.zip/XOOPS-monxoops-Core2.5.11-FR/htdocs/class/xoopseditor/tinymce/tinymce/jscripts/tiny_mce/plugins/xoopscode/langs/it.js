tinyMCE.addI18n('it.xoopscode',{
    code_desc:"Inserisci codice"
});
