/**
 */

tinyMCE.addI18n('en.xoopsemotions',{
    desc : 'Insert Xoops emotions',
    delta_width : '0',
    delta_height : '0'
});